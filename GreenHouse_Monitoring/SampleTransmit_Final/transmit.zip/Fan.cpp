#include "Fan.h"

Fan::Fan(const int pin) : Switchable(pin)
{
    
}
